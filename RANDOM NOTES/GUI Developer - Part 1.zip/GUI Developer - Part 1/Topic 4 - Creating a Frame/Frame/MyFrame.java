

import javax.swing.JFrame;

public class MyFrame{

   public static void main(String[] args){

     // Create a JFrame
     JFrame frame = new JFrame("MyFrame");

     // Set the frame size
     frame.setSize(400,300);

     // Centre a frame
     frame.setLocationRelativeTo(null);

     // Close the frame upon exit
     frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

     // Display the frame
     frame.setVisible(true);

   }// main

}// class