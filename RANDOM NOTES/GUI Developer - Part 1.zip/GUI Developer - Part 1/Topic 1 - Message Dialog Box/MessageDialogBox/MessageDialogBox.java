import javax.swing.JOptionPane;

public class MessageDialogBox{

   public static void main (String[] args){
         JOptionPane.showMessageDialog(null,"Java GUI Developer","Welcome User",JOptionPane.INFORMATION_MESSAGE);
   }// main

}// class